// var 变量  demo 变量名称(自定义)
var demo = document.getElementById('demo')
// alert(demo);
// function 创建函数  action() 函数名称(自定义)
function action(){
    demo.className = 'active';
}