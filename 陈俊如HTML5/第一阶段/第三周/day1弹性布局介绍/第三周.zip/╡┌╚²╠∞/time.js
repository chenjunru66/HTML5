// Date() 日期方法，获取当前的日期
var now = new Date();
// alert(now)

// 获取当前的秒钟，按秒计
var seconds = now.getSeconds();
// alert(seconds)
// 获取当前的分钟，按分计
var minutes = now.getMinutes();
// alert(minutes)
// 获取当前的小时，按时计，24小时制，%取余数
var hours = now.getHours() % 12;
// alert(hours)

// 获取秒钟指针的父级标签
var second = document.getElementById('second');
var minute = document.getElementById('minute');
var hour = document.getElementById('hour');

//创建变量赋予当前animation-delay的值
var h = -3 * 60 * 60 - hours * 60 * 60 - minutes * 60 - seconds ;
// var h = (-3 - hours)  ;
var m = -15 * 60 - minutes * 60 -seconds; 
var s = -15 - seconds;

// 标签.style.样式名称 = 样式值
second.style.animationDelay = s + 's' ;
minute.style.animationDelay = m + 's' ;
hour.style.animationDelay = h + 's';
// <div style="animation-delay:2s;"> </div>