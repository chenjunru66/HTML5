var playList = [
    { name: '传奇', singer: '王菲', src: '传奇.mp3', pic: 'wf.png' },
    { name: '知道不知道', singer: '刘若英', src: '知道不知道.mp3', pic: 'lry.jpg' }];
