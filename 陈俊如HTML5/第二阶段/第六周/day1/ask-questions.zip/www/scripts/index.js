/**
 * Created by Administrator on 2016/9/20.
 */
//$('#user').click(function(){
//    location.href = 'login.html'
//})
console.log($.cookie() )
var petname = $.cookie('petname')
if( petname ){
    $('#user').find('span').last().text(petname)
} else {
    $('#user').removeAttr('data-toggle').find('span').last().click(function(){
        location.href = 'login.html'
    })
}
$('.dropdown-menu li').last().click(function(){

    $.get('/user/signout', null, function(res){
        //console.log(res)
        if( res == 'success' ){
            location.href = '/'
        }
    })
})
//如果存在登录用户名，可跳转到提问页面，否则，跳转到登录页面
$('#ask').click(function(){
    if( petname ){
        location.href = 'ask.html'
    } else {
        location.href = 'login.html'
    }
})
//显示提问的问题
$.get('/questions', null, function(res){
    console.log(res)
    var datas = res.questions
    console.log(datas)
    var divs = ''
//    遍历取出所有的提问的内容
    for( var i = 0; i < datas.length; i++ ){

        divs += "<div class='main'>"
        divs += "<div class='main-left'>"
        divs += "<img src='uploads/" + datas[i].petname + ".jpg' />"
        divs += "</div>"
        divs += "<div class='main-right'>"
        divs += "<h4>" + datas[i].petname + "</h4>"
        divs += "<p>" + datas[i].content + "</p>"
        divs += "<p>" + datas[i].time + "</p>"
        divs += "</div>"
        divs += "</div>"

    }
    $('.questions').html(divs)

})
$('.main').click(function(){
    console.log('111')
    location.href = 'answer.html'
})
