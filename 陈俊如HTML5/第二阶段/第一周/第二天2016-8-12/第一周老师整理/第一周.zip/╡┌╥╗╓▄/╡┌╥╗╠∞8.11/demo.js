var demo = document.getElementById('demo')
demo.innerHTML = '这是通过JS插入的内容'