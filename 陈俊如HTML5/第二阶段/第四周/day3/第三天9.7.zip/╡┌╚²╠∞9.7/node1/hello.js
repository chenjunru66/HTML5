var a = 1;
var b = 2
console.log(a + b)